import React from 'react';
import products from '../data/products.json';
import './ProductSection.css';

const ProductCard = () => {
  return (
    <div className="container-fluid py-4 px-custom">
      <h2 className="mb-4 fw-bold text-center">Produk</h2>
      <div className="row">
        {products.map((product) => (
          <div className="col-6 col-md-4 col-lg-2 mb-4" key={product.id}>
            <button
              className="card product-card h-100 shadow-sm text-start p-0 border-0 bg-white"
              onClick={() => alert(`Produk: ${product.name}`)}
            >
              <img
                src={require(`../assets/${product.image}`)}
                className="card-img-top"
                alt={product.name}
              />
              <div className="card-body px-2 py-3">
                <p className="mb-1 fw-medium">{product.name}</p>
                <p className="fw-bold text-orange mb-1">{product.price}</p>
                <p className="text-muted mb-1">{product.supplier}</p>
                <p className="mb-1 d-flex align-items-center">
                  <img
                    src="https://flagcdn.com/id.svg"
                    alt="Indonesia"
                    width="20"
                    className="me-1"
                  />
                  Indonesia
                </p>
                <p className="mb-1 text-primary">
                  Status Pajak : Non PKP
                </p>
                <p className="mb-1 text-primary">
                  Kategori : {product.category}
                </p>
                <p className="mb-0 text-danger d-flex align-items-center">
                  <i className="bi bi-geo-alt-fill me-1"></i>
                  {product.location}
                </p>
              </div>
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ProductCard;
