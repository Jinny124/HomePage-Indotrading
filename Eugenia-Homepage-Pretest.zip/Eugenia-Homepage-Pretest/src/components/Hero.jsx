import React from 'react';
import { Container, Row, Col, Button, Carousel } from 'react-bootstrap';
import './Hero.css';

import banner from '../assets/banner.webp';
import banner2 from '../assets/banner2.webp';
import banner3 from '../assets/banner3.webp';

const HeroSection = () => {
  return (
    <div className="hero-section bg-light py-4 container-fluid">
      <Container fluid>
        <Row className="align-items-stretch">
          <Col md={3} className="bg-white shadow-sm rounded kategori-list">
            <div className="kategori-header bg-danger text-white px-3 py-2 fw-bold">
              KATEGORI
            </div>
            <ul className="list-unstyled m-0 px-2 py-2">
              {[
                'Alat Berat',
                'Alat Elektronik',
                'Alat Industri',
                'Alat Mekanik dan Suku Cadang',
                'Alat Pelindung Diri',
                'Alat Ukur dan Survey',
                'Bahan Kimia',
                'Karet dan Plastik',
                'Konstruksi dan Properti',
                'Lampu dan Aksesoris',
                'Mesin',
                'Perkakas'
              ].map((item, index) => (
                <li
                  key={index}
                  className="kategori-item d-flex justify-content-between py-1"
                >
                  {item}
                  <span>{'>'}</span>
                </li>
              ))}
              <li className="kategori-item text-danger fw-bold mt-2">
                SEMUA KATEGORI {'>'}
              </li>
            </ul>
          </Col>

          <Col md={9} className="pe-4">
            <Carousel fade interval={4000} className="shadow-sm rounded">
              <Carousel.Item>
                <img
                  className="d-block w-100"
                  src={banner}
                  alt="Banner 1"
                />
              </Carousel.Item>
              <Carousel.Item>
                <img
                  className="d-block w-100"
                  src={banner2}
                  alt="Banner 2"
                />
              </Carousel.Item>
              <Carousel.Item>
                <img
                  className="d-block w-100"
                  src={banner3}
                  alt="Banner 3"
                />
              </Carousel.Item>
            </Carousel>
          </Col>
        </Row>
      </Container>
    </div>
  );
};

export default HeroSection;
