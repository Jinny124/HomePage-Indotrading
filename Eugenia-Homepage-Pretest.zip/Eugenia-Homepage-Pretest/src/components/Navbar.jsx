import React from 'react';
import { Navbar, Nav, Container, Button, Form, FormControl, InputGroup, Dropdown } from 'react-bootstrap';
import { FaSearch, FaGlobe } from 'react-icons/fa';

import logo from '../assets/logo.jpeg';
import messagesIcon from '../assets/messagesIcon.jpg';
import cartIcon from '../assets/cartIcon.png';
import helpIcon from '../assets/helpIcon.jpg';
import loginIcon from '../assets/loginIcon.png';

import './Navbar.css';

const MyNavbar = () => {
  return (
    <Navbar bg="light" expand="lg" sticky="top" className="shadow-sm py-2">
      <Container fluid>
        <Navbar.Brand href="#">
          <img src={logo} alt="Indotrading Logo" height="60" />
        </Navbar.Brand>

        <Navbar.Toggle aria-controls="main-navbar" />

        <Navbar.Collapse id="main-navbar">
          <Form className="search-form my-2 my-lg-0 mx-lg-3 d-flex flex-grow-1">
            <InputGroup className="rounded-input w-100">
              <FormControl
                type="search"
                placeholder="Ketik Kebutuhan Anda"
                aria-label="Search"
              />
              <Button variant="danger" className="search-button">
                <FaSearch className="me-2" />
                Cari
              </Button>
            </InputGroup>
          </Form>

          <Nav className="ms-auto d-flex align-items-center gap-3 flex-wrap mt-2 mt-lg-0">
            <Dropdown>
              <Dropdown.Toggle
                variant="link"
                className="lang-selector d-flex align-items-center"
              >
                <FaGlobe size={18} className="me-2" />
                <span>Indonesia</span>
              </Dropdown.Toggle>
              <Dropdown.Menu>
                <Dropdown.Item>Indonesia</Dropdown.Item>
                <Dropdown.Item>English</Dropdown.Item>
              </Dropdown.Menu>
            </Dropdown>

            <Nav.Link href="#" className="nav-icon">
              <img src={messagesIcon} alt="Messages" width="25" height="25" />
              <span>Messages</span>
            </Nav.Link>

            <Nav.Link href="#" className="nav-icon fw-semibold">
              <img src={cartIcon} alt="Cart" width="25" height="25" />
              <span>Keranjang</span>
            </Nav.Link>

            <Nav.Link href="#" className="nav-icon">
              <img src={helpIcon} alt="Help" width="25" height="25" />
              <span>Help</span>
            </Nav.Link>

            <Nav.Link href="#" className="nav-icon">
              <img src={loginIcon} alt="User" width="25" height="25" />
              <span>Login / Daftar</span>
            </Nav.Link>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
};

export default MyNavbar;
