import React from 'react';
import './ProductCategories.css';

import dummyC1 from '../assets/dummyC1.webp';
import dummyC2 from '../assets/dummyC2.webp';
import dummyC3 from '../assets/dummyC3.webp';
import dummyC4 from '../assets/dummyC4.webp';
import dummyC5 from '../assets/dummyC5.webp';
import dummyC6 from '../assets/dummyC6.webp';
import dummyC7 from '../assets/dummyC7.webp';
import dummyC8 from '../assets/dummyC8.webp';
import dummyC9 from '../assets/dummyC9.webp';
import dummyC10 from '../assets/dummyC10.webp';
import dummyC11 from '../assets/dummyC11.webp';
import dummyC12 from '../assets/dummyC12.webp';
import dummyC13 from '../assets/dummyC13.webp';
import dummyC14 from '../assets/dummyC14.webp';
import dummyC15 from '../assets/dummyC15.webp';
import dummyC16 from '../assets/dummyC16.webp';
import dummyC17 from '../assets/dummyC17.webp';
import dummyC18 from '../assets/dummyC18.webp';

const categories = [
  {
    title: 'LAMPU DAN AKSESORIS',
    items: [
      { name: 'Mobile Light Tower', image: dummyC1 },
      { name: 'Lampu Disco', image: dummyC2 },
      { name: 'Tiang High Mast', image: dummyC3 },
      { name: 'Lampu Stadion', image: dummyC4 },
      { name: 'Lampu Stadion', image: dummyC5 },
      { name: 'Lampu Sorot Halogen', image: dummyC6 },
      { name: 'Tiang Traffic Light', image: dummyC7 },
      { name: 'Lampu Taman', image: dummyC8 },
      { name: 'Lampu Tenaga Surya', image: dummyC9 }
    ]
  },
  {
    title: 'ALAT PELINDUNG DIRI',
    items: [
      { name: 'Segitiga Pengaman', image: dummyC10 },
      { name: 'Body Harness', image: dummyC11 },
      { name: 'Carabiner', image: dummyC12 },
      { name: 'Baju Chemical', image: dummyC13 },
      { name: 'Inspection Mirror', image: dummyC14 },
      { name: 'Life Raft', image: dummyC15 },
      { name: 'Alat Pemadam Kebakaran', image: dummyC16 },
      { name: 'Dermaga Apung', image: dummyC17 },
      { name: 'Kawat Segel', image: dummyC18 }
    ]
  }
];

const ProductCategories = () => {
  return (
    <section className="product-category-section">
      <h2 className="mb-4 fw-bold text-center">Kategori Produk</h2>
      <div className="container-fluid">
        <div className="row">
          {categories.map((category, idx) => (
            <div key={idx} className="col-md-6 mb-5">
              <div className="category-box">
                <h4 className="category-title fw-bold">{category.title}</h4>
                <div className="category-grid mt-3">
                  {category.items.map((item, index) => (
                    <div key={index} className="category-item">
                      <p className="category-name fw-bold">{item.name}</p>
                      <img src={item.image} alt={item.name} />
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProductCategories;
