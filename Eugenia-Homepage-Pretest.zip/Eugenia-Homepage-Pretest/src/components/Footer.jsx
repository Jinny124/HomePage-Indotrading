import React from 'react';
import logoPay from '../assets/logoPay.png';
import googlePlayLogo from '../assets/googlePlayLogo.png';
import lkppLogo from '../assets/lkppLogo.png';
import belaPengadaanLogo from '../assets/belaPengadaanLogo.png';
import './Footer.css';

const Footer = () => {
  return (
    <footer className="footer text-light">
      <div className="container-fluid py-3">
        <div className="row gy-3 px-4">
          <div className="col-md-4">
            <h5 className="fw-bold mb-4">B2B MARKETPLACE INDONESIA</h5>
            <p className="mb-2">
              IndoTrading.com adalah B2B Marketplace, Direktori Bisnis Supplier Terbesar di Indonesia.
            </p>
            <p>
              Situs Jual Beli khusus B2B Marketplace, B2B E-commerce, Pusat Distributor, Pabrik,
              Supplier, Agen, Grosir, Importir, Eksportir dan Penyedia Jasa terlengkap di Indonesia.
            </p>
            <p>
              Segera Daftarkan perusahaan anda dan dapatkan akses ke informasi proyek, tender, dan
              website gratis untuk perusahaan anda.
            </p>
          </div>

          <div className="col-md-2">
            <h6 className="mb-4">INFORMASI</h6>
            <ul className="footer-list">
              <li>Hubungi Kami</li>
              <li>Indotrading FAQ</li>
              <li>Testimonial</li>
              <li>Karir</li>
              <li>Partners</li>
              <li>Event Indotrading</li>
              <li>Terms & Condition</li>
              <li>Privacy Policy</li>
            </ul>
          </div>

          <div className="col-md-2">
            <h6 className="mb-4">BELI</h6>
            <ul className="footer-list">
              <li>Produk Terbaru</li>
              <li>Kategori Produk</li>
              <li>Kategori Perusahaan</li>
              <li>Cara Belanja di</li>
              <li>Register as Buyer</li>
            </ul>

            <h6 className="mt-4 mb-4">JUAL</h6>
            <ul className="footer-list">
              <li>Perusahaan Terbaru</li>
              <li>Cari Proyek</li>
              <li>Daftar Jadi Supplier</li>
            </ul>
          </div>

          <div className="col-md-2">
            <h6 className="mb-4">OUR SERVICE</h6>
            <ul className="footer-list">
              <li>Premium Supplier</li>
              <li>Premium Buyer</li>
              <li>SEO Services</li>
              <li>Google Ads</li>
              <li>Youtube Ads</li>
              <li>Social Media Ads</li>
              <li>Google Display Network</li>
              <li>Email Bisnis</li>
              <li>Buat Website</li>
              <li>Toko Daring</li>
            </ul>

            <div className="col-auto language-switcher mt-4">
              <div className="language-box">
                <div className="lang-option top">INDONESIA</div>
                <div className="lang-option bottom">ENGLISH</div>
              </div>
            </div>
          </div>

          <div className="col-md-2">
            <h6 className="mb-4">FOLLOW US</h6>
            <div className="footer-social mb-3 d-flex gap-2">
              <i className="bi bi-twitter"></i>
              <i className="bi bi-facebook"></i>
              <i className="bi bi-youtube"></i>
              <i className="bi bi-instagram"></i>
            </div>

            <h6 className="mt-4 mb-4">DOWNLOAD OUR APPS</h6>
            <img
              src={googlePlayLogo}
              alt="Google Play"
              width="150"
            />

            <h6 className="mt-4 mb-4">MITRA RESMI DARI</h6>
            <div className="mitra-logos">
              <img
                src={lkppLogo}
                alt="LKPP"
                width="180"
                className="mitra-logo mb-3"
              />
              <img
                src={belaPengadaanLogo}
                alt="Bela Pengadaan"
                width="180"
                className="mitra-logo"
              />
            </div>
          </div>
        </div>

        <br />
        <br />

        <div className="footer-bottom text-center text-light">
          <div className="mb-2">
            Indonesia | Jakarta | Bali | Bandung | Semarang | Surabaya | Pontianak |
            Samarinda | Makassar | Manado | Palembang | Medan | Yogyakarta
          </div>

          <div className="mb-2 text-center">
            Bayar dengan
            <img
              src={logoPay}
              alt="Indotrading Pay"
              className="mx-2 footer-logo"
            />
            untuk transaksi aman & nyaman
            <a href="#" className="text-info text-decoration-none ms-1">
              Pelajari Lebih Lanjut
            </a>
          </div>

          <div className="small">
            © 2025 Indotrading - Indonesia B2B Marketplace Direktori Bisnis Indonesia
            All Rights Reserved.
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
