import logo from './logo.svg';
import './App.css';
import MyNavbar from './components/Navbar';
import HeroSection from './components/Hero';
import ProductCard from './components/ProductSection';
import Footer from './components/Footer';
import ProductCategories from './components/ProductCategories';

function App(){
  return (
    <div>
      <MyNavbar />
      <HeroSection/>
      <ProductCategories/>
      <ProductCard/>
      <Footer/>
    </div>
  );
}

export default App;
